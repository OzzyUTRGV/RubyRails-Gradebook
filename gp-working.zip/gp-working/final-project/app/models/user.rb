
class User < ApplicationRecord

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable


  devise :database_authenticatable, 
         :recoverable, :rememberable, :validatable
    
    validates_presence_of :account_id
    validate :account_id_must_be_zero_or_one
    
    def account_id_must_be_zero_or_one
    
        if account_id != nil
            if (account_id != 0) && (account_id != 1)
                errors.add(:account_id, "value must be zero or one #{account_id}")
            end
        end
    end
end
