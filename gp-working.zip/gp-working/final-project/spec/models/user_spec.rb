require 'rails_helper'

RSpec.describe User, type: :model do
    
    it "requires a account id to be valid" do
        user = User.new(email: "ta@ta.com",password: "default123")
        expect(user).to be_invalid
    end


    it "requires account id must be zero or one" do
        user = User.new(email: "ta@ta.com",password: "default123", account_id: 100)
        expect(user).to be_invalid
    end
end