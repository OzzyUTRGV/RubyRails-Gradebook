FactoryBot.define do
  factory :user do
      
      sequence(:email) { |n| "person-#{n}@example.com" }
      password { '123greetings' }
    
      trait :valid do
        account_id {1}
      end
      trait :invalid do
        account_id {10}
	  end
	  trait :ta do 
		account_id {0}
	  end
      
    end
end